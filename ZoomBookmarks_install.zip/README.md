# Qt_ZoomBookmarks

Simple tool for managing all your online Meetings and an easy way to attend them with one click.

## Installation

All needed files and libraries are contained in the 'ZoomBookmarks_install.zip' file.<br>
Download and unpack the .zip file to a certain directory.<br>
Subsequently, you are ready to run the programm by double clicking the 'ZoomBookmarks.exe' file.<br>

## Copyright

ZoomBoomarks - Manage your online meetings.
Copyright (C) 2022  Bastian Hartmann

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
